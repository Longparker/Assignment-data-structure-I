#include<stdio.h>
int main(){
    int h,b;
    for(h=1;h<=10;h++){
        printf("%dHi ",h);
    }
    for(b=1;b<=10;b++){
        printf("\t%dBye ",b);
    }
}