#include<stdio.h>
int main(){
    int n;
    for(n=0;n<=30;n++){
        if(n%2==0){
            printf("%d ",n);
        }
    }
}
