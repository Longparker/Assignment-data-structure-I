#include<stdio.h>
int main(){
    int sum=0,i;
    for(i=1;i<=100;i++){
        printf("%d ",i);
        sum=sum+i;
    }
     printf("\n Total sum number from 1 to 100 is:%d",sum);
    
}