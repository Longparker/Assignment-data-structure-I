#include<stdio.h>
#include<windows.h>
int main(){
    int k=0;
    int i;
    //printf("Enter number :");
    //scanf("%d",&i);
    for(i=99;i>=1;i--){
        k=k+i;
        printf("%d ",i);
    }


}

